---
name: 🐛 Bug Report
about: Crie um relatório para nos ajudar a melhorar
title: '[BUG] '
labels: bug
assignees: ''

---

## 🐛 Descrição do Bug

Uma descrição clara e concisa do bug.

## 🔄 Para Reproduzir

Passos para reproduzir o comportamento:

1. Vá para '...'
2. Clique em '....'
3. Role até '....'
4. Veja o erro

## ✅ Comportamento Esperado

Uma descrição clara do que você esperava que acontecesse.

## 📸 Screenshots

Se aplicável, adicione screenshots para ajudar a explicar o problema.

## 🖥️ Ambiente

- **OS:** [ex: Windows 10, macOS 12, Ubuntu 20.04]
- **Navegador:** [ex: Chrome 120, Firefox 121, Safari 17]
- **Versão do FleetControl Pro:** [ex: 1.0.0]

## 📋 Logs

```
Adicione logs de erro do console do navegador aqui
```

## 📝 Informações Adicionais

Adicione qualquer outra informação sobre o problema aqui.
