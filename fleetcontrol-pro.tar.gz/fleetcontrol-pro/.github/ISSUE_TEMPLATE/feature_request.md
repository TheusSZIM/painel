---
name: 💡 Feature Request
about: Sugira uma ideia para este projeto
title: '[FEATURE] '
labels: enhancement
assignees: ''

---

## 💡 Sua Sugestão

Uma descrição clara e concisa do que você gostaria que fosse adicionado.

## 🤔 Problema Relacionado

O problema que esta feature resolveria. Ex: "Sempre fico frustrado quando..."

## ✅ Solução Desejada

Uma descrição clara do que você quer que aconteça.

## 🔄 Alternativas Consideradas

Uma descrição de soluções alternativas que você considerou.

## 📸 Mockups / Screenshots

Se aplicável, adicione mockups ou screenshots para ilustrar sua ideia.

## 📝 Informações Adicionais

Adicione qualquer outra informação ou contexto sobre a solicitação de feature aqui.
