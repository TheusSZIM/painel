## 📝 Descrição

Descreva as mudanças feitas neste PR.

## 🔄 Tipo de Mudança

- [ ] 🐛 Bug fix (mudança que corrige um problema)
- [ ] ✨ Nova feature (mudança que adiciona funcionalidade)
- [ ] 📚 Documentação (mudança apenas na documentação)
- [ ] 💄 Estilo (formatação, sem mudanças de código)
- [ ] ♻️ Refatoração (mudança de código que não corrige bug nem adiciona feature)
- [ ] ⚡ Performance (melhoria de performance)
- [ ] 🧪 Testes (adição ou correção de testes)

## ✅ Checklist

- [ ] Meu código segue as diretrizes de estilo do projeto
- [ ] Eu fiz uma autoavaliação do meu código
- [ ] Eu comentei meu código, especialmente em áreas difíceis de entender
- [ ] Eu fiz as mudanças correspondentes na documentação
- [ ] Minhas mudanças não geram novos warnings
- [ ] Eu testei em diferentes navegadores (Chrome, Firefox, Safari, Edge)
- [ ] Eu testei em diferentes tamanhos de tela (mobile, tablet, desktop)

## 📸 Screenshots

Se aplicável, adicione screenshots das mudanças.

## 🔗 Issues Relacionados

Fixes #(número da issue)

## 📝 Notas Adicionais

Adicione qualquer informação adicional que possa ser útil para os revisores.
